var mysql2 = require('mysql2/promise');

exports.handler = async (event) => {
    console.log(`event: ${JSON.stringify(event)}`);

    let response = {};

    const connectionConfig = {
        host: 'database-3.cskwdxm3zntq.us-east-2.rds.amazonaws.com',
        user: 'admin',
        password: 'admin1234',
        database: 'aws_db'
    };

    let connection;

    try {
        connection = await mysql2.createConnection(connectionConfig);
    } catch (err) {
        console.error('error connecting to the database');
        console.error(err);
        response = {
            statusCode: 500,
            "headers": {
                "Content-Type": "application/json"
            },
            body: 'error connecting to the database'
        };
        return response;
    }

    console.info(`connected as id ${connection.threadId}`);

    try {

        const [rows, fields] = await connection.execute(event.query);
        console.info(`rows: ${JSON.stringify(rows)}`);
        console.info(`fields: ${JSON.stringify(fields)}`);
        const responseBody = {
            number: rows.length,
            contacts: rows
        };
        response = {
            statusCode: 200,
            "headers": {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(responseBody)
        };
    } catch (err) {
        console.error('error running query');
        console.error(err);
        response = {
            statusCode: 500,
            "headers": {
                "Content-Type": "application/json"
            },
            body: 'error executing query'
        };
    }

    await connection.end();

    return response;
};